This ModelDistribution and Model are very tentative and do not yield very explainable results. Readers
are encouraged to experiment with the prior model parameters, the pdf and standard deviation calculations
to hopefully obtain results that do not so rapidly converge on the m0 cluster.