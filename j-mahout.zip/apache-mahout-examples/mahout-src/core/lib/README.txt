This directory contains those libraries that aren't currently published to the Maven repository.  We should periodically check back with the repository to see if they become available, then we can remove the JAR from here.

Commons CLI version is: commons-cli-2.0-20080905.032905-1.jar but renamed to be 2.0-mahout for release purposes.
