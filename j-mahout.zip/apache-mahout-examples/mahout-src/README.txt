Welcome to Apache Mahout!

Mahout is a scalable machine learning library that implements many different approaches to machine learning.  The project
 currently contains implementations of algorithms for classification, clustering, genetic programming and
 collaborative filtering, all
 enabled to scale by leveraging the power of Hadoop's Map-Reduce (http://hadoop.apache.org) implementation.

 Getting Started

 See http://cwiki.apache.org/MAHOUT/quickstart.html

 Legal

 Please see the NOTICE.txt included in this directory for more information.

Documentation

See http://lucene.apache.org/mahout and http://cwiki.apache.org/MAHOUT.
